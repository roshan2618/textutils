const a = "Pulkit";
const b = "Raghvendra";
const c = "Sarthak";
const d = "Nagendra";

export default a;
export {b};
export {c};
export {d};